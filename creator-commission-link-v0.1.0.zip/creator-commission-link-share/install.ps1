[CmdletBinding()]
param(
    [string]$DestinationRoot = (Join-Path ([Environment]::GetFolderPath('UserProfile')) '.agents\skills')
)

$ErrorActionPreference = 'Stop'
$sourceSkill = Join-Path $PSScriptRoot 'creator-commission-link'
if (-not (Test-Path -LiteralPath (Join-Path $sourceSkill 'SKILL.md') -PathType Leaf)) {
    throw 'Skill source is incomplete. Extract the full archive before installing.'
}
$resolvedRoot = [IO.Path]::GetFullPath($DestinationRoot)
$targetSkill = Join-Path $resolvedRoot 'creator-commission-link'
if (Test-Path -LiteralPath $targetSkill) {
    throw "Target already exists; no files changed: $targetSkill"
}
New-Item -ItemType Directory -Path $resolvedRoot -Force | Out-Null
Copy-Item -LiteralPath $sourceSkill -Destination $targetSkill -Recurse
foreach ($sourceFile in Get-ChildItem -LiteralPath $sourceSkill -Recurse -File) {
    $relativeFile = $sourceFile.FullName.Substring($sourceSkill.Length + 1)
    $targetFile = Join-Path $targetSkill $relativeFile
    if (-not (Test-Path -LiteralPath $targetFile -PathType Leaf)) {
        throw "Installation incomplete; missing: $relativeFile"
    }
    $sourceHash = (Get-FileHash -LiteralPath $sourceFile.FullName -Algorithm SHA256).Hash
    $targetHash = (Get-FileHash -LiteralPath $targetFile -Algorithm SHA256).Hash
    if ($sourceHash -ne $targetHash) {
        throw "Installation verification failed: $relativeFile"
    }
}
Write-Output "Installed and verified: $targetSkill"
Write-Output 'Open a new Codex conversation and invoke $creator-commission-link. Restart Codex if it is not listed.'
