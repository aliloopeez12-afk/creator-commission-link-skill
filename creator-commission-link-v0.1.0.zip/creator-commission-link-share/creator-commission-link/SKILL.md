---
name: creator-commission-link
description: "达人绑定佣金：按平台处理达人佣金和商品链接，支持抖音主商品指定达人、团长活动报名及明确要求的发票豁免，返回实际截图和可复制产品链接。用于绑佣金、做链接、报团、发票豁免及对应流程维护。"
---

# 达人绑定佣金

统一入口按平台分支执行，逐条定位店铺、商品、达人与佣金条件，保存原生结果和证据。独立投流、预算、ROI、授权监控不属于本技能。

## 接手顺序

1. 首次使用、换电脑或缺少工作目录时，读[初始化](references/setup.md)。工作目录由当前使用者选择，不能套用发布者的路径、商品表或登录状态。
2. 已初始化时先读业务工作目录的 `PROJECT_MEMORY.md`、`CURRENT_STATE.md`、`SHOP_CONFIG.md` 和当前批次；实际使用来源表前再读 `SOURCE_REGISTER.md`。
3. 按[业务规则](references/business-rules.md)与[通用流程](references/workflow.md)核实本次已有授权和必要输入。相同目标已设置时核验交付，不重复提交；结果不明先查询。
4. 按下面的路由只加载本任务平台与定制；开始后台操作前核对本次店铺和可用浏览器能力。

## 按需路由

| 任务 | 指南 |
| --- | --- |
| 浏览器准备、外部Chrome、登录中断 | [浏览器访问](references/browser-access.md) |
| 抖音主商品指定达人佣金 | [抖音绑定达人](references/platforms/douyin.md) |
| 抖音团长招商链接报名 | [抖音报团](references/platforms/douyin-institution.md) |
| 明确要求达人发票豁免 | [抖音豁免](references/platforms/douyin-invoice-exemption.md) |
| 店铺、机构或合作类型差异 | [定制规则](references/customizations.md)，以及本机 `SHOP_CONFIG.md` |
| 截图与可复制链接 | [交付模板](assets/delivery.md) |
| 记录新批次／实际问题 | [批次模板](assets/batch-record.md)、[问题模板](assets/issue-record.md) |
| 持续提炼或查经验 | [维护方法](references/maintenance.md)、[经验索引](references/lessons.md) |

已观察验证的主路径是抖音主商品指定达人使用既有固定或双佣金策略绑定及刷新回读。报团、豁免包含操作者手动提交后的回读；助手自动新建／转换策略、新建专属或赠品商品、其他平台步骤尚无完整自动执行验收。不能把方法文档、安装通过或历史验证当作当前店铺已办理成功。

每个完成对象都向当前使用者返回实际截图和完整产品链接；待生效、待审核与生效中按原生状态分别说明。用户接管时停止编辑，恢复先重查。业务数据保存在本机工作目录；本共享包不包含真实账号、商品、达人、来源表或后台证据。
