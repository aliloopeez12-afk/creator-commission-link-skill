# 经验索引

共享版保留方法及范围，不附任何真实店铺案例或私有证据链接。每次真实任务在使用者工作目录保存自己的证据；历史观察不代替本次验收。

| 编号 | 方法 | 正文位置 |
| --- | --- | --- |
| L001 | 登录后进入完整管理页 | [抖音](platforms/douyin.md)第1节及[浏览器](browser-access.md) |
| L002 | 来源指纹、主商品精确搜索及规格补核 | [初始化](setup.md)、[抖音](platforms/douyin.md)第2节 |
| L003 | 既有策略选择、UID识别及同策略多人 | [抖音](platforms/douyin.md)第3节 |
| L004 | 刷新回读、逐人截图和主链接 | [抖音](platforms/douyin.md)第4、5节 |
| L005 | 固定／双佣金区分及商品级范围 | [业务规则](business-rules.md)、[抖音](platforms/douyin.md)第2至4节 |
| L006 | UID、数量已更新但昵称／佣金仍旧的过渡状态 | [抖音](platforms/douyin.md)界面排错 |
| L007 | 来源下架及多个同名候选，用户选定后取实际URL | [抖音](platforms/douyin.md)第2节 |
| L008 | 原值、草稿、当前／待生效及人工接管 | [抖音](platforms/douyin.md)第3、4节、[浏览器](browser-access.md) |

新经验先记本机问题，取得验证结果后按[维护方法](maintenance.md)并回所属正文，不按每次聊天创建同义技能。
