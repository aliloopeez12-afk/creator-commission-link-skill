# 业务工作目录入口

这是空白模板，初始化时填实际信息，不包含可直接执行的业务参数。

- 本机业务工作目录：待使用者选择。
- 技能入口：初始化时填本机实际SKILL.md位置。
- 目标平台与店铺范围：待确认。
- 当前进度：[CURRENT_STATE.md](CURRENT_STATE.md)。
- 本店配置：[SHOP_CONFIG.md](SHOP_CONFIG.md)。
- 商品来源：[SOURCE_REGISTER.md](SOURCE_REGISTER.md)。

真实输入后在本目录创建 `batches/`、`issues/` 及必要证据；数据留在本机，不提交技能共享仓库。操作规则在安装的技能中维护，这里只放本店入口和当前事实。
